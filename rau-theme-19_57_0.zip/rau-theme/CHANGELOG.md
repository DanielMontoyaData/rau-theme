# Historial de cambios — tema RAU

De la versión **19.1.0** a la **19.22.0**. Revisión completa del tema: las 54 herramientas, la
portada, las 36 plantillas, la capa de proxies, la tabla normativa, seguridad, accesibilidad y SEO.

Cada corrección se verificó contra una fuente externa o con una prueba numérica antes de aplicarla.
Donde no fue posible verificar, está dicho.

---

## Errores de cálculo

**Yagi: el reflector medía lo mismo que el radiador.** `10.06m / 10.06m`. El reflector tiene que ir
~5% más largo; con la misma medida no hay desfase de corriente entre elementos y la antena no
tiene directividad — es un dipolo caro. Estaba en el banco rápido y en la calculadora completa, y
el comentario del código decía "misma fórmula ya verificada en la herramienta completa", así que la
verificación cruzada propagó el error en vez de detectarlo. A 14.15 MHz ahora da radiador 10.06 m
(0.475λ), reflector 10.54 m (0.497λ) y director 9.36 m (0.442λ), contra la referencia clásica
0.473 / 0.495 / 0.440λ.

**Grid squares: 124 km de error, en cinco copias.** La conversión de cuadrícula a coordenadas
estaba duplicada en Maidenhead, Azimuth, Cobertura de Repetidor, Predicción de Pasadas y la página
de cada repetidor. Todas sumaban el desplazamiento al centro del cuadro de 2°×1° (+1 / +0.5) y
**encima** el del subcuadro. Una de ellas dividía además el ancho del subcuadro entre 12 sin razón.
El error medido es de 124 km — más que el alcance de cualquier repetidor de 2m, así que el
simulador de cobertura daba veredictos sin sentido. Comprobado contra los cuatro puntos que la
propia página cita: FJ26ff → 6.2292 N, 75.5417 W.

**Grayline: dos horas corrido.** Signo de la longitud invertido y el del ángulo horario cruzado.
Para Medellín daba amanecer 08:03 y atardecer 19:50 cuando lo real es 05:55 y 18:07. Justo en la
herramienta que sirve para cronometrar la ventana de propagación del grayline.

**Satélites: se medía la distancia sobre el suelo.** La lista mostraba la distancia al punto
subsatelital, ignorando la altura de la órbita: la ISS aparecía a 9.411 km cuando su alcance máximo
real ronda los 2.300 km. Además marcaba con estrella como "más cercano" un satélite que estaba al
otro lado del planeta. Ahora usa el slant range real y la elevación, y los que están bajo el
horizonte lo dicen en vez de mostrar un número que invita a apuntar la antena.

**Maidenhead: `undefined` en una de cada cuatro posiciones.** La página de Modo Emergencia
reutilizaba el alfabeto de 18 letras de los *campos* (A–R) para los *subcuadros*, que usan 24
(a–x). Bogotá salía como `FJ24undefinedr`. Medellín cae en el índice 5, así que quien lo probó
desde la sede lo vio funcionar. Verificado con un barrido de 120.000 posiciones.

**Maidenhead: redondeo en los límites.** La función principal dividía por `0.0416667`, que es 1/24
truncado. Con una coordenada justo en el límite de un subcuadro (`lat%1 = 0.5`) daba 11,99999 en
lugar de 12 y devolvía la letra anterior. Ahora multiplica, que es exacto. Ambas implementaciones
coinciden en 443.700 posiciones comparadas.

---

## Datos incorrectos

**Potencias del decreto: mal en las quince filas.** El artículo 38 del Decreto 963 de 2009 no fija
potencia por banda, sino por rango de frecuencias, categoría de licencia y tipo de estación. La
tabla se había inventado un número por banda. En VHF decía 500 W cuando el máximo legal es 100 W
para la categoría más alta — cinco veces por encima, en la banda que más se usa y donde está la
repetidora del club. Reemplazada por la tabla real del articulado, con las tres categorías y la
distinción entre estación fija y móvil.

**Bandas del Novicio.** El artículo 34 designa banda por banda y tipo de emisión qué puede usar la
Segunda Categoría. La tabla negaba 6m al Novicio, que sí la tiene autorizada, y daba por completas
80m y 10m, que están recortadas. En 15m, 6m y 70cm el Novicio solo tiene CW y datos, no fonía.

**Pérdidas de coaxial: sobreestimadas 2,5 veces.** La fórmula usa 100 MHz de referencia pero las
cifras del selector eran las de ~450 MHz. Con 20 m de RG-58 en 2m decía 10,5 dB —9 W de 100—
cuando lo real ronda 4 dB. Corregidas las ocho según hojas de datos de Belden, Times Microwave y
CommScope.

**FT4 en 40 metros.** Decía 7.090, que es una frecuencia real pero de **concurso** (FT Roundup) y
para FT8. La estándar de FT4 es 7.0475, según la documentación de WSJT-X.

**HK4 no es el Eje Cafetero.** El artículo 35 asigna la zona 4 a Antioquia y Chocó; el Eje
Cafetero es la zona 6. Único error factual del banco de preguntas del examen, y justo en la zona
donde está el club.

**Tonos CTCSS.** El título decía "67 tonos estándar". La tabla tiene 38 — el 67 era el valor del
primer tono, 67.0 Hz, confundido con la cantidad.

**RST.** S9 decía "Muy fuerte" cuando S8 ya es "Fuerte"; en la escala estándar S9 es un grado por
encima, extremadamente fuerte.

**Tabla de prefijos: de 57 a 329 entradas.** Tenía 22 de Sudamérica, 17 de Norteamérica, 10 de
Europa, 5 de Asia, 3 de Oceanía y **ninguna de África**. Los países usan bloques enteros asignados
por la UIT, no un prefijo suelto: faltaban Japón entero salvo JA, España salvo EA, Polonia salvo
SP. Se añadieron los bloques completos y 67 entidades DXCC ausentes. Las zonas ITU/CQ son las de
la capital: para países que abarcan varias son aproximadas, y está anotado.

---

## Datos ausentes presentados como datos

Un patrón que se repitió cuatro veces: `||0` y `typeof x === 'undefined'` convierten "la fuente no
respondió" en un valor concreto, y el sitio afirma algo que nadie dijo.

- **Índice K, en la portada y en la herramienta de propagación.** `parseInt(d.kindex)||0` hacía que
  un dato ausente se anunciara como **"condiciones excelentes para HF"**, con la aguja en verde.
- **Alertas de banda.** Cualquier condición que no fuera *good* ni *fair* se pintaba roja como
  "Pobre", incluidos los huecos que el proxy rellena con un guion.
- **Historial SFI/K.** Un día sin registro se dibujaba como cero y la línea caía al fondo, que se
  lee como un desplome solar en vez de como un hueco en el archivo.

---

## Fallos que tumbaban la página

**`MORSE is not defined`.** Al unificar las tres copias de la tabla Morse la declaré con `const` a
media altura del archivo. Un `const` no existe hasta que su línea se ejecuta, así que el
`ReferenceError` abortaba el resto del script y los cuatro paneles del final —DX Spots, DMR, WSPR,
D-STAR— se quedaban en "Cargando…" indefinidamente. **Este error lo introduje yo** al corregir otro.
Las tablas compartidas están ahora al principio del archivo.

**20 enganches de eventos sin protección.** `document.getElementById('x').addEventListener(...)` a
nivel superior: si el id no existe, `TypeError` y muere todo lo que venga después. Ahora pasan por
`rauOn()`, que avisa por consola y sigue.

**Módulo huérfano.** La herramienta de DX se rehízo con un iframe pero el JavaScript viejo quedó
ejecutándose: lanzaba una petición inútil a `admin-ajax.php` en cada carga y reventaba al pintar
sobre elementos que ya no existían.

---

## DX Spots: cuatro fallos apilados

Todos producían el mismo síntoma, "Sin spots disponibles ahora mismo":

1. `is_array($data)` siempre daba verdadero, así que la rama que manejaba respuestas envueltas en
   objeto era código muerto.
2. El campo del spotter se buscaba como `de_call_sign`; en DXSummit se llama `de_call`.
3. El endpoint de dxheat.com devolvía HTTP 404 — retirado.
4. El timeout de 4 segundos no alcanzaba para cruzar el Atlántico.

Los dos primeros se encontraron leyendo el código; los otros dos solo aparecieron con el modo
diagnóstico añadido para el caso. La frecuencia además se mostraba con un decimal: un spot en
14.024 se copiaba al portapapeles como "14.0", y 28.450 se redondeaba a "28.5", al otro lado de la
banda.

---

## Duplicaciones eliminadas

Ocho, y en cinco las copias ya habían divergido:

| Duplicado | Copias | ¿Habían divergido? |
|---|---|---|
| Grid square → coordenadas | 5 | sí, todas mal |
| Haversine y rumbo | 5 | no |
| Fórmula de Yagi | 2 | no, ambas mal |
| Tabla de prefijos | 2 | no |
| Tabla Morse | 3 | sí, dos sin la barra `/` |
| Calendario de concursos | 2 | no |
| Fase lunar | 2 | no |
| Potencias del decreto | 2 | sí, la segunda quedó sin corregir |

Sigue triplicada la conversión de Maidenhead entre check-in, RAU Field y herramientas, pero las
tres son correctas y unificarlas obligaría a cargar 290 KB de scripts para usar veinte líneas. La
comprobación 15 del guion vigila que no diverjan.

---

## Seguridad

**SSRF en la suscripción de notificaciones.** El endpoint guardaba la URL tal como llegaba y el
servidor **luego le enviaba peticiones**. Cualquier visitante anónimo podía registrar una dirección
de la red interna del hosting o el servicio de metadatos de la nube. Ahora solo se aceptan URLs
https de los servicios push reales de los navegadores; probado contra diez vectores, incluido un
dominio que imita al de Google.

**Escrituras ilimitadas.** El registro del bot era el único endpoint que escribe en la base sin
límite por IP. Como solo conserva las últimas 200 entradas, bastaba con repetir la llamada para
desplazar todas las preguntas reales.

**Cabeceras de IP falseables.** El contador de banderas confiaba en `HTTP_X_FORWARDED_FOR` sin
condiciones. Ahora rechaza rangos privados y reservados. Los límites por IP de los formularios usan
`REMOTE_ADDR` directamente, que no se puede falsear — eso ya estaba bien y conviene que siga así.

---

## Rendimiento

**Diez proxies sin caché de fallos.** Ninguno guardaba nada cuando la fuente externa fallaba, así
que mientras un servicio estuviera caído cada visitante volvía a intentarlo y esperaba el timeout
completo. Con varios paneles en la misma página eso se acumula. El envoltorio `rau_remote_get()`
marca la URL como caída dos minutos: de 40 segundos de espera acumulada a 4, en la simulación con
diez visitantes.

---

## Accesibilidad

- **42 campos de formulario sin etiqueta accesible.** Casi todos tenían `placeholder`, que no
  cumple esa función y además desaparece al escribir.
- **5 botones que solo contenían un icono**, anunciados como "botón" a secas.
- **Patrón de pestañas a medias**: 54 `role="tabpanel"` y ningún `role="tab"`, que es peor que no
  poner nada. Los 54 paneles de herramienta no son pestañas —son navegación con URL propia— y
  pasaron a `role="region"` con nombre. Los dos grupos que sí lo son recibieron el patrón completo
  con navegación por flechas.
- **Contraste**: el texto atenuado a opacidad parcial daba 4,19:1 y 3,44:1, por debajo del mínimo
  AA, en 35 usos de tipografía pequeña. El borde de los campos daba 1,61:1 cuando la norma pide
  3:1 para lo que identifica un control.

Queda pendiente lo que necesita un navegador: orden de tabulación real, trampas de foco y si
conviene anunciar con `aria-live` los paneles que se refrescan solos.

---

## SEO

**Las 54 herramientas eran invisibles.** Cada una tiene URL propia generada por una regla de
reescritura. WordPress no lo sabía: su canonical las declaraba a todas copias de `/herramientas/`,
que le dice a Google explícitamente que indexe solo una. Y ninguna estaba en el sitemap, porque el
del core recorre entradas reales. Ahora hay canonical propio, `og:url` correcto y un proveedor de
sitemap que las registra.

Pendiente, y es trabajo de diseño: la imagen de Open Graph es el badge de 640×591, pero la tarjeta
se declara `summary_large_image`, que espera algo cercano a 1200×630.

---

## Herramienta nueva

**Ángulo de Radiación** (`/herramientas/angulo/`). Frecuencia y altura de la antena → ángulo del
lóbulo principal, lóbulos secundarios y una lectura en lenguaje llano. Detecta el caso NVIS por
debajo de λ/4, que en Colombia es lo que se busca para cobertura nacional en 40m y 80m. Contrastada
contra la tabla clásica: λ/2 → 30°, 1λ → 14,5°, 2λ → 7,2°.

---

## Simulador RABCA

Además del error de HK4: una pregunta contenía la respuesta literal en el enunciado, y el barajado
era `sort(() => Math.random() - 0.5)`, un algoritmo sesgado. Medido sobre 200.000 tiradas, la
respuesta correcta caía en la 2ª o 3ª posición el **76%** de las veces. Como en el banco la
correcta suele ser la segunda opción del array, se podía aprobar apostando siempre por las de en
medio sin saber nada de radio. Reemplazado por Fisher-Yates. Se añadieron tres preguntas sobre
normativa colombiana verificada.

---

## Rendimiento: un intento fallido, documentado

Los 289 KB de JavaScript van en línea dentro del HTML. Como las 54 herramientas tienen URL propia,
navegar de una a otra vuelve a descargarlos enteros: recorrer cinco transfiere 1,4 MB de código
idéntico. Servirlo como archivo aparte lo arreglaría.

**Se intentó dos veces y falló las dos en este alojamiento.** Primero por regla de reescritura: la
dirección devolvía 404 y la página cargaba entera sin una sola línea de JavaScript. Después por
parámetro de consulta con el manejador en `parse_request`: HTTP 500.

Se revirtió por completo. El ahorro es real pero no compensa el riesgo de dejar la página
inutilizable, y cada intento costó un despliegue con el sitio caído. Queda documentado para que
nadie lo reintente sin saber que ya se probó; la comprobación 16 del guion lo vigila.

Si algún día se retoma, la lección es que el veredicto no se puede juzgar a ojo: lo que decide si
el navegador ejecuta el archivo es la cabecera `Content-Type`, y un archivo servido como
`text/html` se ve idéntico a uno servido bien.

---

## Verificación automática

`php bin/verificar.php` — 16 comprobaciones en la 19.34.0 (18 desde la 19.36.0, contando la 3b), cada una nacida de un fallo que estuvo en producción.
Devuelve 0 o 1, así que sirve en un gancho de git. Probado reintroduciendo ocho fallos históricos:
los detecta todos. Ver `bin/README.md`.

---

## 19.57.0 — Módem de audio, JS8, propagación de Colombia en vivo, avisos al celular y vista previa al compartir

- **Vista previa al compartir un enlace** (WhatsApp, Telegram, Facebook, Discord, Slack)
  - Las páginas creadas desde la cuenta de trabajo de Claude salían firmadas «claude-temporal» en la
    vista previa: Telegram, Discord y Slack leen el autor del oEmbed de WordPress. Ahora el oEmbed
    dice «RAU — Radioaficionados Unidos» y enlaza a la portada, sea quien sea el autor de la página.
  - /emergencias/ no tenía etiquetas sociales: ahora lleva título, descripción, imagen (el escudo),
    URL canónica y tarjeta de Twitter/X.
- **Módem de audio RAU** (`assets/radio/modem.js`): pasa los registros del centro de mando de un
  celular a otro **como sonido**, por la radio (FM o SSB), por cable o de parlante a micrófono.
  - Tramas de 8 bytes protegidas con el mismo código que FT8 (LDPC 174/91 y CRC-14), en 8 tonos de
    fase continua con sincronía Costas. El mensaje completo lleva además su CRC-16.
  - Dos velocidades: robusta (50 baudios, ≈5 bytes/s) y rápida (100 baudios, ≈10 bytes/s). El
    receptor escucha las dos a la vez, corrige ±150 Hz de desfase y avisa qué tramas faltan para
    reenviar solo esas. Medio segundo de tono inicial abre el VOX.
  - Medido con ruido blanco en 2500 Hz: la robusta decodifica el 100 % a −10 dB y la rápida a −6 dB.
    También con relojes distintos (300 ppm) y eco de sala de 20 ms.
  - En «Campo → Pasar registros sin internet» (medio «Sonido») y en «Recibir → 🎤 Escuchar el
    módem». Funciona sin internet: el service worker guarda el módem.
- **JS8 en el receptor** (botón «JS8» junto a FT8 y FT4; submodo Normal)
  - Port del decodificador de JS8Call (GPL v3: tablas LDPC 174/87, CRC-12, Costas, varicode,
    Huffman y compresión JSC). La sincronía y la etapa fina son las de `ftx.js`, que JS8 comparte con
    FT8.
  - En las 7 grabaciones de prueba del modo Normal que trae JS8Call: **30 de los 31 mensajes que
    espera JS8Call (97 %)**, con varias pasadas restando lo decodificado. Cero decodificaciones en 40
    grabaciones de FT8/FT4 y en ruido.
  - Muestra el texto como JS8Call («KN4ZXG: @HB HEARTBEAT FM16», «KG9B: KN4CRD HEARTBEAT SNR -14»),
    arma los mensajes de varios marcos y ubica en el mapa a quien manda cuadrícula.
  - El diccionario de compresión de JS8Call (262 144 palabras, 1 MB comprimido) se baja solo la
    primera vez que se usa JS8.
  - **Al centro de mando**: con sesión iniciada, lo decodificado (salvo los latidos) se envía al sitio
    y la sala lo muestra en «Ahora mismo» como «JS8 oído en el receptor HK4RAU», primero lo dirigido a
    grupos de emergencia (@EMCOMM, @ARES, @RACES…), con quién lo reportó. Sin sesión no se acepta nada.
- **Propagación desde Colombia en vivo** (debajo del receptor, en sus dos pestañas)
  - Cada 10 minutos se consultan en PSK Reporter los reportes de las cuadrículas FJ y FK y se guardan
    los enlaces de la última hora con un lado en Colombia (incluye San Andrés y Malpelo).
  - Mapa por banda, con quién de aquí se oye afuera y a quién se oye desde aquí, distancia máxima y
    regiones. Endpoint público `/wp-json/rau/v1/propagacion` con caché de 2 minutos.
  - El centro de mando muestra el resumen («Abiertas desde Colombia») junto a la regla de NVIS.
- **Avisos al celular del centro de mando** (Web Push con las llaves VAPID del tema), con la página
  cerrada. Se activan en «Alarmas → 📱 Avisos en este celular».
  - En el momento: mensaje de EMERGENCIA, URGENCIA reportada por una estación, incidente crítico.
  - Por tiempo: mensaje de emergencia sin entregar a los 10 min; incidente crítico sin responsable a
    los 15 min.
  - Cada aviso sale una vez. A quien registró el evento no se le avisa. En un simulacro el aviso lo
    dice. Las suscripciones vencidas se borran solas.
- **Pruebas nuevas**: módem (9), JS8 (7; la opcional con las grabaciones de JS8Call exige ≥90 %),
  propagación (11), JS8 al centro de mando (10), avisos (15), módem de punta a punta entre dos
  navegadores con micrófono simulado, y JS8 en el E2E del receptor.

---

## 19.56.0 — OSD, mapa, skimmer de CW, ajustes de audio y hora; centro de mando más liviano

- **FT8/FT4: OSD** (decodificación por estadísticas ordenadas, como `osd174_91` de WSJT-X).
  - Cuando falla la decodificación normal, toma los 91 bits más confiables como base y prueba
    cambiar uno o dos de los menos seguros.
  - En las 22 grabaciones de prueba sube de 337 a **351 de los 362 mensajes de WSJT-X (97 %)**.
  - En sintéticos, a −21 dB pasa de 7 a 12 de 24 en FT8; a −16 dB, de 11 a 16 en FT4.
  - Para no inventar mensajes, por OSD solo se acepta un mensaje estándar con indicativos bien
    formados. Resultado: cero falsos en 45 ranuras de solo ruido y en 480 señales sintéticas.
    Los 13 mensajes nuevos que salen de las grabaciones tienen locator coherente con el país del
    indicativo.
- **FT8/FT4 en el receptor**
  - Ganancia fija y audio sin compresión ADPCM mientras decodifica; se restauran al salir.
  - La hora del equipo se compara con la del servidor (nueva acción AJAX `rau_hora`, en
    milisegundos): si está corrida más de 1 s se avisa, y la corrección de hora arranca ya
    compensada.
  - **Mapa** de las estaciones oídas que envían su locator, con la distancia al receptor.
  - **Modo rápido** automático si el equipo tarda más de media ranura en decodificar.
- **Skimmer de CW** («todas las señales»)
  - Lee a la vez todas las estaciones de CW que caben en el filtro ancho, cada una con su propio
    decodificador. Probado con 4 estaciones simultáneas de 15 a 28 PPM.
  - Tocar una línea sintoniza esa estación.
  - Los clics de manipulación de una estación fuerte no abren canales falsos.
- **CW**
  - El nivel de marca tiene memoria: tras una pausa entre turnos la primera raya ya no se acorta
    (antes «CQ» salía «FQ»).
  - Una E o T sola y dudosa al final de una transmisión se descarta.
  - Banco de pruebas: 39,8 % de caracteres errados (el decodificador anterior al de la 19.55.0,
    67,9 %).
- **Centro de mando más liviano**
  - El esquema y el directorio salen del HTML: el esquema pasa a un archivo estático versionado
    (lo guarda el service worker) y el directorio se pide a la API, con copia para usar sin
    internet.
  - La configuración en la página baja de 24 KB a 1,9 KB, y la página comprimida de unos 6,4 KB a
    2,4 KB.
- **Pruebas**
  - FT8/FT4: 10, con la de OSD (y la opcional con grabaciones exige ≥95 %).
  - CW: 9, con la del skimmer.
  - Receptor: 5, con ajustes de audio, mapa, skimmer y hora del servidor.

---

## 19.55.0 — Decodificadores FT8, FT4 y CW nuevo en el receptor

En las dos pestañas del receptor KiwiSDR: la página /receptor/ y la pestaña de Herramientas. Ambas
usan el mismo componente.

- **Grupo «Decodificador»** en los mandos: Ninguno · CW · FT8 · FT4.
- **FT8 y FT4**
  - Al elegirlos se sintoniza la frecuencia estándar de la banda en USB con filtro ancho.
  - Al cerrar cada ranura UTC (15 s o 7,5 s), el audio se decodifica en un *worker* del navegador.
  - Se muestra una lista como la de WSJT-X: UTC, dB, DT, Hz y mensaje.
  - Se resaltan los CQ y las estaciones colombianas (HK, HJ, 5J, 5K), con filtro «solo CQ».
  - La hora de la ranura sale de los paquetes de audio que llegaron con menos demora, con una
    corrección que se ajusta sola con el DT de lo decodificado.
- **Motor FT8/FT4** (`assets/radio/ftx.js`)
  - Es una traducción de ft8_lib de Kārlis Goba (licencia MIT, incluida en
    `assets/radio/LICENSE-ft8_lib.txt`): cascada, candidatos por Costas, LDPC(174,91), CRC-14 y
    desempaquetado de los 77 bits.
  - Le agrega una segunda etapa como la de WSJT-X: bajada a banda base, sincronía fina, métricas
    de 1, 2 y 3 símbolos coherentes y resta de lo decodificado, hasta en 3 pasadas.
  - En las 22 grabaciones de prueba de ft8_lib decodifica **337 de los 362 mensajes que sacó
    WSJT-X (93 %)**, frente al 74 % de ft8_lib sola. Además saca 22 mensajes válidos que la
    referencia no tiene, y ningún texto basura.
  - Con señales sintéticas decodifica todo hasta −18 dB en FT8 y −14 dB en FT4, sin
    decodificaciones falsas.
  - Tarda unos 1,6 s por ranura FT8 en un computador.
  - La SNR es aproximada: dentro de ±1 dB con señales sintéticas y con mediana igual a la de
    WSJT-X en grabaciones reales, pero con ±6 dB de dispersión.
- **CW nuevo** (`assets/radio/cw.js`)
  - Tono exacto por espectro y detector coherente con un filtro a la medida de la velocidad
    (13 Hz a 20 PPM).
  - Niveles adaptativos que siguen el QSB, silenciador para el ruido y recalibración con los
    últimos 3 s al encontrar una estación.
  - Cada letra se lee como la secuencia válida de Morse más probable; las letras pegadas se
    separan.
  - En el banco de pruebas (19 casos, 6 textos cada uno) se equivoca en el 41 % de los
    caracteres, frente al 68 % del decodificador anterior:
    - con 3 dB de SNR, del 1 al 14 % hasta 30 PPM (el anterior, del 77 al 85 %);
    - a 40 PPM con buena señal, el 4 % (el anterior, el 36 %);
    - con mano irregular, el 3,5 % (el anterior, el 42 %).
  - Las letras dudosas se muestran tenues y las muy improbables se descartan.
- **Sala de mando**: la «Pantalla de sala» vuelve arriba al activarse.
- **Pruebas nuevas**
  - `tests/radio/ftx.test.mjs` (9): codificación, decodificación FT8/FT4 sintética, ruido, resta
    y comparación con las grabaciones de ft8_lib si se le da la carpeta.
  - `tests/radio/cw.test.mjs` (8).
  - `tests/radio/receptor.e2e.mjs` (3): navegador real con un KiwiSDR simulado que entrega audio
    en su formato.

---

## 19.54.0 — Sala de mando: control de red, alarmas, comandos y herramientas de trabajo

El centro de mando deja de ser una colección de formularios.

- **Sala de mando** (nueva vista de entrada):
  - Franja de estado con grupo fecha-hora, período operacional, red, alarmas, incidentes, tráfico y
    estaciones.
  - Paneles de red, mapa, alarmas, cola de tráfico, incidentes, registro en vivo y período.
  - Pantalla de sala para un proyector.
- **Línea de comandos** para registrar al ritmo de la radio (`HK4ABC tráfico 2 P`,
  `HK4ABC urgente …`, `red dirigida 7.060 LSB`, `nota …`). Muestra lo que va a registrar antes de
  hacerlo.
- **Control de red**:
  - Estado de la red (abierta, dirigida, cerrada).
  - Cola de palabra por urgencia, precedencia y espera.
  - «Paso», contacto, sin respuesta, salida y fuera de servicio con un toque.
  - Guiones para leer por radio.
  - Registro ICS-309.
- **Alarmas con antigüedad**:
  - Cubren estaciones en silencio, mensajes sin entregar según precedencia, incidentes críticos sin
    responsable o sin verificar, solicitudes sin respuesta, acciones vencidas, SITREP atrasado y fin
    del período.
  - Tienen sonido, aviso del sistema y «enterado» por dispositivo.
  - La coordinación ajusta los límites.
- **Período operacional** con objetivos al estilo SCI-202, y **relevo de turno** generado de la
  bitácora.
- **Perfil de enlace** sobre el terreno real (Copernicus GLO-90 vía Open-Meteo): curvatura, zona de
  Fresnel, pérdida en espacio libre, rumbo y punto crítico.
- **Lluvia** observada y pronosticada en el incidente (Open-Meteo, con el punto redondeado). Se aclara
  que no es una alerta oficial.
- **Tablero de tráfico** por estado y antigüedad.
- **Paquetes sin internet**:
  - Texto comprimido con suma de verificación, en partes para radio, mensajería o QR.
  - Se reciben pegados o escaneados, aun sin tener la operación.
  - Los registros recibidos quedan marcados «por paquete».
- **Otros arreglos**:
  - Sismos en español.
  - Marca de «Datos REALES» en simulacros.
  - Tabla de frecuencias compacta.
  - Cabecera de celular en dos filas.
  - Con coordenadas, la precisión ya no queda «desconocida».
  - El mapa de la sala no tapa la barra inferior del celular (lo detectó la prueba 4).
- **Esquema 3**: tipos `red`, `periodo` y `ajuste`; `contacto` admite precedencia, ubicación y salida.
  El servidor valida con el mismo esquema: el período y los ajustes son de coordinación.
- **Pruebas**: núcleo 24 (6 nuevas), API 14 (1 nueva), E2E 21 (6 nuevas, con reloj simulado para las
  alarmas y respuestas fijas para Open-Meteo).

---

## 19.53.1 — revisión en vivo de la 19.53.0

- **El mapa tapaba los formularios.** Las capas de Leaflet usan z-index de 400 a 1000 y el modal 50:
  con el simulador corriendo y el mapa abierto, la tarjeta «Llega por radio» y sus botones quedaban
  debajo del mapa; al desplazarse, el mapa también pasaba por encima de la cabecera y de la barra
  inferior del celular. El contenedor del mapa ahora forma su propio contexto de apilamiento
  (`isolation: isolate`). La prueba E2E 11 abre un formulario sobre el mapa y comprueba qué queda
  encima (falla sin el arreglo, pasa con él).

---

## 19.53.0 — Centro de mando integral: incidentes, trazabilidad, roles, mapa y simulador

La misma ruta `/emergencias/` pasa de ser una libreta compartida a un centro de mando de comunicaciones
de emergencia. Documentación completa (arquitectura, API, seguridad, despliegue, recuperación y
limitaciones) en `EMERGENCIAS.md`.

**Problemas de la 19.52.0 que se corrigen**
- **Almacenamiento**: todo estaba en localStorage, de unos 5 MB y sin estructura. Ahora se usa IndexedDB,
  con migración automática.
- **Una sola clave por operación y sin roles**: cualquiera con la clave podía cerrar la operación o
  borrar el plan. El token salía de la clave y no se podía revocar por dispositivo.
- **Cualquiera podía crear una operación visible en la lista pública.** Ahora solo se listan las que
  tienen una organización verificada por el administrador.
- **El servidor solo limpiaba el texto**: no validaba el tipo de registro ni el permiso. Lo inválido se
  descartaba sin aviso.
- **No había incidentes individuales**: la «operación» era el incidente. No había verificación, prioridad
  de despacho, historial por incidente ni duplicados.
- **Mensajes**: tenían cuatro estados que no distinguían enviado, recibido por un nodo, entregado ni confirmado.
- **Estaciones**: «bien / apoyo / urgente» mezclaba la situación con el estado del equipo, y un reporte
  viejo seguía viéndose como vigente.
- **Frecuencias**: el símplex de llamada 146.520 aparecía como frecuencia «de emergencia».
- **Faltaba** el mapa, la auditoría, la conservación de datos, el simulador y las pruebas automáticas.

**Servidor** (`inc/emergencias/`)
- **Roles**: administrador, coordinador, operador de comunicaciones, responsable de recursos, observador
  y usuario de simulación.
  - Con cuenta de WordPress, cada usuario ve solo las operaciones de su organización.
  - Sin cuenta, se entra con claves dictadas por radio: la de operadores o la de coordinación (distintas,
    guardadas como hash), o con invitaciones con rol, vencimiento y número de usos.
- **Sesiones por dispositivo**: con token aleatorio guardado solo como hash, vencen y se revocan una por una.
- **Esquema único** (`assets/emergencias/esquema.json`): lo valida el servidor por tipo, campo y rol.
  Lo inválido se rechaza con su motivo.
- **Auditoría** de todas las acciones sensibles.
- **Conservación**: 90 días después del cierre, los datos de personas se reducen a iniciales.
- **Lista pública**: solo muestra operaciones de organizaciones verificadas.
- **API REST** `rau-em/v1`, documentada; sus respuestas no se guardan en caché.
- **Directorio de frecuencias** por categoría, con fuente, jurisdicción, condiciones y fecha de
  verificación. Editarlo exige fuente y queda auditado. La categoría institucional queda vacía a
  propósito, por falta de fuente oficial.
- **Herramientas → Centro de mando**: organizaciones, operaciones, conservación, restauración de
  respaldos y auditoría.

**Aplicación**
- **Dashboard** con filtros: lugar, incidente, prioridad, estado, organización y periodo.
  - Cada cifra abre su vista y muestra su hora de actualización y la calidad del dato (confirmado,
    reportado, vencido).
  - «Atención ahora» y, en computador, el mapa junto a la actividad reciente.
- **Incidentes con ciclo completo**:
  - Verificación por coordinación; prioridad del reporte separada de la prioridad de despacho.
  - Responsable, decisiones, acciones pendientes, vínculos a mensajes y recursos, e historial.
  - Duplicados sugeridos por distancia, hora, tipo y texto, que fusiona una persona.
  - Exportación CAP en estado borrador o ejercicio.
- **Centro de comunicaciones**:
  - Modelo de mensaje independiente del medio.
  - Estados creado → en cola → enviado → recibido por nodo → entregado → confirmado, cada uno con su
    evidencia.
  - Intentos y errores registrados, y formatos para leer por radio, radiograma e ICS-213 (adaptación no
    oficial).
  - Procedimientos alternativos y estado explícito de cada transporte: solo voz y CW manual están activos.
- **Estaciones y enlaces**:
  - Estados disponible (verificada), reportada, no verificada, degradada, fuera de servicio y desconocida.
  - Una ventana de vigencia configurable; pruebas de enlace, pase de lista y repetidoras con antigüedad.
- **Plan de comunicaciones** en versiones: borrador → propuesto → aprobado por un responsable.
  Imprimible y exportable.
- **Recursos y personal**: solicitud, aprobación, asignación, desplazamiento, despliegue y liberación con
  resultado. Se muestra la última ubicación conocida, sin seguimiento en tiempo real.
- **Mapa operativo** (Leaflet 1.9.4 servido desde el tema):
  - Diez capas; precisión exacta, aproximada o solo de municipio; procedencia y verificación en cada punto.
  - Búsqueda de coordenadas, locator, elementos propios y lugares (Nominatim, a pedido).
  - Se crean incidentes o puntos desde el mapa y se exporta GeoJSON.
  - Sin internet, muestra el contorno de Colombia (Natural Earth) y los mosaicos ya vistos.
- **Informes**:
  - SITREP desde los registros, con fecha de corte, fuentes, responsable, limitaciones y pendientes;
    sin cifras estimadas.
  - Informe de cierre con lecciones aprendidas.
  - Calidad de datos: conflictos, duplicados, datos vencidos y vacíos.
  - Exportación a CSV, GeoJSON y JSON; PDF con la impresión del navegador.
- **Modo de campo**:
  - Instalable como aplicación; modo compacto y modo sol.
  - Cola visible de pendientes y rechazados, reintentos con espera creciente y estado del almacenamiento.
  - Conflictos detectados (dos cambios simultáneos sobre lo mismo) que se resuelven a mano.
- **Administración**: sesiones, revocación, invitaciones, cambio de claves, cierre y respaldo.
- **Simulador**:
  - Nueve escenarios con inyecciones por tiempos y datos ficticios «SIM…».
  - Mide tiempos de respuesta; aislado de toda operación real.
- **Accesibilidad**: enlace para saltar al contenido, foco atrapado en los diálogos, etiquetas, avisos
  en vivo y atajos (/ n m e Alt+1…9 ?).

**Pruebas** (ver EMERGENCIAS.md)
- Núcleo: 18 pruebas.
- API: 13 pruebas.
- Cuentas, organizaciones, conservación y directorio: 17 comprobaciones.
- De punta a punta en Chromium: 15 pruebas, con dos operadores, corte de internet, recarga, observador,
  revocación, mapa y simulador.

---

## 19.52.0 — Centro de Mando de Emergencias (/emergencias/)

Una aplicación nueva e independiente para operar comunicaciones de emergencia, abierta a
radioaficionados de toda Colombia. Se diseñó a partir de lo que pasó en el sismo de magnitud 7,4 del
10 de agosto de 2026 (Chocó y Eje Cafetero), según los reportes de la IARU Región 2 publicados por la
ARRL, la IARU Región 1, ARNewsline y la UBA:
- La red de la Liga operó 124 horas seguidas.
- La red celular y el wifi cayeron en minutos.
- Varias repetidoras se apagaron porque la transferencia automática al generador no funcionó.
- Los bomberos de Dosquebradas pasaron a usar repetidoras de radioaficionado.
- Se entregaron 15 radios a la Gobernación de Risaralda.

**Cómo funciona**
- **Sin internet primero.** Todo lo registrado queda en el teléfono. El service worker guarda la
  página y sus dos archivos, así que abre sin conexión después de una primera visita.
- **Clave de red por incidente, sin cuentas.** Quien activa el incidente dicta por radio un código
  de 6 letras (sin O/0 ni I/1) y la clave. Los demás operadores se unen con ambos.
- **Registros que solo se agregan.** Cada cosa es un evento con un identificador único creado en el
  teléfono, y el estado se calcula recorriéndolos en orden. Así, los registros de varios operadores
  se combinan sin conflictos, y un teléfono que estuvo horas sin señal entrega lo suyo al volver.
- **Sincronización** cada 15 s y al recuperar la señal. Si no hay internet, se pasa un respaldo en
  archivo a otro teléfono (Bluetooth, cable o WhatsApp) y se importa sin duplicar.
- **Simulacros** con una franja visible «SIMULACRO · NO ES UNA EMERGENCIA REAL», y mensajes marcados
  como PRUEBA.

**Módulos**
- **Tablero:**
  - Cifras de estaciones, mensajes, personas y repetidoras.
  - «Atención ahora»: urgencias, mensajes de emergencia sin entregar, estaciones calladas y repetidoras caídas.
  - Acciones rápidas, últimos registros, banda recomendada y alertas.
- **Red:**
  - Registro de estaciones con estado, energía, mensajes pendientes, ubicación y GPS (locator).
  - Reloj de último contacto contra un intervalo de reporte configurable.
  - Pase de lista que llama a las estaciones en orden, con su indicativo en fonético.
- **Mensajes:**
  - Radiograma con precedencia (emergencia, prioridad, bienestar, rutina), instrucciones HX,
    numeración y cuenta de palabras automáticas.
  - SCI-213 para organismos.
  - Texto «para leer por radio» con el indicativo en fonético.
  - Estados: recibido, retransmitido a… y entregado, con historial.
- **Bitácora:** todo lo del incidente en orden, en hora UTC, con buscador. Exporta el SCI-214.
- **Plan de comunicaciones (SCI-205):**
  - Asignaciones por función.
  - Estado de cada repetidora: en el aire, con batería, con generador o caída.
  - Frecuencias nacionales. Se puede imprimir.
- **Bienestar:** «estoy bien» y búsqueda de familiares, sin datos médicos.
- **Recursos y directorio** del incidente, con los teléfonos 123, 132, 144 y 119.
- **Herramientas de campo:** autonomía de batería, dipolo NVIS, deletreo fonético y posición GPS
  con la repetidora más cercana.
- **Inicio (guardia):**
  - Incidentes abiertos en el país.
  - Sismos de magnitud 3,5 o más de los últimos 7 días (USGS) y alertas de GDACS para Colombia. El feed
    del Servicio Geológico Colombiano responde «acceso denegado».
  - Qué bandas oye el receptor HK4RAU y cuál usar dentro de Colombia: 40 m de día, 80 m de noche.
  - Listas de preparación (maletín, estación, coordinación) con fecha de revisión y vencimiento.
- **Modo sol** de alto contraste, botones de 44 px o más y una versión para imprimir.

**Frecuencias nacionales verificadas**
- 7060, 7240, 7275, 3985, 14300, 18160 y 21360 kHz, y 146.520 MHz: las que la Liga activó en agosto de 2026.
- El panel «Frecuencias de Emergencia» de Herramientas decía que faltaban porque no estaban
  verificadas. Ahora las muestra con su fuente y enlaza al centro de mando.
- El pie de página y el Modo Emergencia también enlazan al centro de mando.

**Servidor**
- Dos tablas: incidentes y eventos. El índice único por identificador evita los duplicados.
- La clave solo se guarda como hash, y el teléfono guarda un token derivado de ella.
- Límites por conexión: crear incidentes, intentos de clave y registros por hora.
- Todo el texto se limpia antes de guardarlo.
- En Herramientas → Incidentes de emergencia, un administrador puede borrar incidentes si hay abuso.

**Probado** con dos operadores, uno en computador y otro en celular, en el mismo simulacro:
- El segundo se une con código y clave, ve lo del primero, registra sin internet y sincroniza al volver la señal.
- La página abre sin conexión y se puede crear un incidente local.
- No hubo errores de JavaScript ni scroll horizontal.

---

## 19.51.1 — revisión en vivo de la 19.51.0

- **Arranque más fiable.** La emisora se elegía con las últimas 10 líneas de la cascada (≈1,4 s).
  Con desvanecimiento ganaba la que estuviera en un pico: una vez quedó en 11860 kHz a S5, mientras
  11930 llegaba a S8. Ahora se promedian todas las líneas desde que la banda queda centrada (≈3,5 s).
  En 6 arranques con el Kiwi real eligió 11930 cinco veces; la sexta, 11860, que en ese momento
  llegaba igual de fuerte (S8).
- **Consola: «Receptor: escuchando».** La etiqueta de arriba decía «muy ocupado» mientras uno mismo
  escuchaba, porque uno de esos canales ocupados es el propio. El receptor avisa con
  `rau:rx-encendido` al encender y al apagar.
- **Mandos en la columna de la consola.** En dos columnas, «FM» y «5 kHz» quedaban solos en otra
  línea. Entre 560 y 980 px de ancho del receptor, cada bloque es ahora una fila y sus mandos caben
  en una sola línea.

---

## 19.51.0 — todo el receptor como un solo equipo, y arranca sonando

**Arranque con algo que oír.** Quien llega por primera vez (sin frecuencia guardada ni enlace)
ya no cae en 40 m, donde a muchas horas no hay nadie. Al pulsar «Escuchar», el receptor revisa la
cascada de la banda de onda corta adecuada para la hora y sintoniza la portadora más fuerte en AM.
- De día (11 a 22 UTC) prueba 25, 16, 19 y 31 m; de noche, 49, 31, 25 y 19 m.
- Una portadora cuenta si sobresale 15 dB sobre la mediana de la cascada; si en una banda no hay
  ninguna, pasa a la siguiente.
- Si la persona mueve el dial mientras tanto, no se toca nada.
- No se usó una lista fija de emisoras ni el S-metro. Con el Kiwi real, a las 10 h de Colombia, la
  banda de 49 m solo tenía ruido local a −75 dBm, igual que la «emisora» de una lista, mientras que
  en 25 m había portadoras de +30 dB. Ese día se sintonizó 11930 kHz.
- Las teclas de BANDA suman OC 19 m y OC 16 m. El panorámico muestra el nombre de WWV en 5, 10 y 15 MHz.

**Debajo del frente, el mismo radio:**
- Línea de estado ámbar con luz de conexión, justo bajo la pantalla.
- Panorámico con bisel, la banda y su SPAN (− 469 kHz +) en la cabecera.
- Decodificador de CW en una segunda pantalla ámbar.
- Mandos en bloques serigrafiados: BANDA, MODO, FILTRO, SINTONÍA · PASO y AUDIO.
  - FILTRO tiene tres teclas con su ancho real según el modo (p. ej. «Angosto 5.0k»). Antes era una lista desplegable.
  - AUDIO reúne VOL, SQL y la tecla AGC. Antes, en la consola, el volumen quedaba escondido en Ajustes.
- Faders propios en vez de los controles del navegador.
- CASCADA (color, contraste) y MEMORIAS: los favoritos son ahora teclas M1, M2… que se encienden si
  estás en esa frecuencia, y «M+ Guardar». En la consola van tras la tecla «☰ Menú».
- La mini barra flotante es un pequeño visor ámbar con Ver y ■.

Probado con el Kiwi real en computador, en la consola y en celular, sin errores de JavaScript ni
desbordes horizontales.

---

## 19.50.1 — receptor más fácil con el dedo

Revisión de uso con el receptor real, midiendo en un celular (Pixel 7):

| | Antes | Ahora |
|---|---|---|
| Zona táctil de cada mitad de dígito | 28 × 17 px | ▲ y ▼ propios de 28 × 24 px, más la mitad del dígito |
| Alto de las teclas | 36 px | 44 px (lo recomendado para el dedo) |
| Ayuda bajo la pantalla | «usa la rueda», también en celular, a 10 px | Texto propio para dedo o ratón, a 12 px en táctil |
| Línea de estado mientras se escucha | «Muy ocupado: prueba igual» | «Conectado: usas uno de los canales» |
| Cascada | 1 px por línea | 2 px por línea: se llena el doble de rápido |

Lo que ya funcionaba se mantiene:
- La perilla gira con el dedo sin desplazar la página (media vuelta = 15 pasos).
- En computador, el radio completo con su cascada cabe en la primera pantalla (1440 × 900).

---

## 19.50.0 — el receptor con frente de radio

El receptor tiene ahora el aspecto y los mandos de un equipo de comunicaciones.

- **Pantalla LCD ámbar.** La frecuencia se escribe como en un radio (7.150.00 MHz) con dígitos de 7
  segmentos (fuente DSEG7, licencia OFL, incluida en `assets/fonts` con su licencia). Detrás va
  «88.888.88» casi apagado, como los segmentos sin encender. Eso también resuelve el hueco que
  dejaba el dígito de 10 MHz oculto: ahora es un segmento apagado. Los dígitos se siguen tocando
  arriba y abajo para sintonizar.
- **Indicadores del LCD.**
  - RX se enciende en verde al escuchar y REC en rojo al grabar.
  - Siempre a la vista: VFO A, modo, ancho del filtro (2.4k…), AGC y banda.
- **S-metro con escala real.** Va de S1 a S9 y de +20 a +60 dB (−127 a −13 dBm), es segmentado, pasa
  de ámbar a rojo sobre S9 y tiene retención de pico.
- **Perilla VFO.** Es moleteada y gira de verdad: con el dedo o el ratón alrededor del centro, con la
  rueda o con las flechas, a un paso cada 12° (30 por vuelta).
- **Teclas con luz de estado.** Bandas, segmentos, modos y pasos llevan una luz ámbar cuando están
  activos (`aria-pressed`). Escuchar es verde y pasa a Detener en rojo.
- **Diseño adaptable al espacio del propio receptor.** Usa consultas de contenedor, no el ancho de la
  ventana:
  - en la página completa, pantalla, perilla y teclas van en una fila;
  - en la columna de la consola y en celular, los mandos van debajo de la pantalla.

**«Abierta ahora».** La banda con más estaciones oídas va arriba. De día ya no se lee primero «40 m ·
nadie oído».

---

## 19.49.0 — página más liviana, bitácora única y decodificador de CW

**Peso de Herramientas.** Los ~400 KB de JavaScript iban en el HTML de cada una de las 61
direcciones, así que se volvían a descargar en cada herramienta y en cada visita. Ahora se guardan
como archivo estático en `wp-content/uploads/rau/`, con el nombre derivado del contenido: si
cambia (versión nueva, una repetidora editada), sale otro archivo. El HTML baja de ~960 KB a
~585 KB. El JavaScript se descarga una vez y queda en el navegador.

Los dos intentos anteriores lo servían a través de WordPress (regla de reescritura: 404; parámetro
de consulta: HTTP 500). Este no pasa por WordPress, y tiene tres protecciones:
1. Solo se usa si el propio servidor comprobó que el archivo responde 200 como JavaScript; si no,
   va en línea como antes, y se reintenta una vez al día.
2. Si en el navegador el archivo no llega o no termina de ejecutarse, la página se recarga sola con
   `?rau_inline=1`, una sola vez, con el JavaScript en línea.
3. Se conservan los tres últimos archivos, para las páginas que LiteSpeed tenga en caché.

Probado borrando el archivo: la página se recuperó sola con la herramienta abierta. La comprobación
16 del verificador ahora exige el respaldo.

**Bitácora única.** La bitácora rápida de la consola y el Log ADIF eran dos libretas. Ahora escriben
en la misma (`rau_log_adif`) y se actualizan entre sí sin recargar. Los QSO de la bitácora vieja
pasan solos al Log ADIF la primera vez. La bitácora separa el RST enviado del recibido y tiene su
botón «⬇ Exportar ADIF».

El exportador ADIF tenía errores. Escribía `<TIME_ON:6>` con 8 cifras, contaba las longitudes en
caracteres y no en bytes UTF-8 (un nombre con ñ corría el resto del registro), y no incluía la
banda. Ahora escribe ADIF 3.1.4 con BAND y, si Mi estación está configurada, STATION_CALLSIGN,
MY_GRIDSQUARE y TX_PWR, que es lo que piden LoTW y QRZ.

**Decodificador de CW en el receptor.** En modo CW aparece debajo de la cascada y escribe lo que se
transmite. Funciona así:
- Busca el tono entre 300 y 900 Hz con filtros Goertzel, cada 8 ms.
- El umbral se adapta al ruido y a la señal.
- Las duraciones se agrupan en puntos y rayas por el salto más grande entre ellas, y cada letra se
  clasifica al terminar. Así no depende de adivinar la velocidad: aprende sola de 5 a 60 PPM.
- Un pulso de más de 1,5 s no es CW (es ruido o una portadora) y pasa a ser el fondo.
- Muestra la velocidad, el tono y la relación señal/ruido. Se reinicia al cambiar de estación.

La configuración se eligió entre 72 combinaciones, midiendo a la vez la velocidad y la sensibilidad:
- **Con señal sintética:** 0 % de caracteres errados de 5 a 40 PPM, con desvanecimiento y con 6 dB de
  señal sobre el ruido. Un QSO completo con números («RST 599 5NN … 73 TU») sale exacto.
- **Con ruido real del receptor** (grabado en 7.020 y 14.100 kHz): no inventa letras, y decodifica
  bien a partir de unos 6 a 10 dB de señal sobre el ruido del filtro. Por debajo no alcanza.
- **Al empezar:** el primer segundo tras conectarse o cambiar de estación se usa para conocer el
  ruido, así que puede perderse la primera letra.
- **Sin prueba con una estación real:** el 24 de octubre no había estaciones de CW reportadas (era el
  CQ WW de fonía) y los radiofaros de 14.100 no se oían.

---

## 19.48.0 — catálogo ordenado, consola armónica y sintonía más intuitiva

**Sintonía.**
- **Dígitos de la frecuencia.** Cada dígito de la frecuencia grande es un control. Tocar su mitad de
  arriba lo sube y la de abajo lo baja. También responde a la rueda y, en pantalla táctil, a
  deslizar el dedo arriba o abajo sobre él.
- **Banda y segmento.** Los 13 botones sueltos pasan a ser la banda (160 a 10 m) más sus segmentos:
  CW, FT8 y fonía, con su frecuencia y el modo correcto. Elegir una banda lleva a fonía (a CW en
  30 m, que no tiene fonía). Aparte quedan onda corta 49, 31 y 25 m, y WWV en 5, 10 y 15 MHz.
- **Dónde estás.** Una línea indica la banda, el segmento y si la frecuencia es para Novicio
  (Decreto 1078) o solo para Primera y Avanzada.
- **Tocar una señal la centra.** Si el toque cae a menos de 12 px de una señal que sobresale 10 dB
  del ruido, el receptor se pone sobre ella. En USB y LSB la deja dentro del filtro de voz y en CW
  en el centro del filtro. En el segmento FT8 no lo hace.
- **Otros controles.**
  - El paso es un selector a la vista (10 Hz, 100 Hz, 1 kHz y 5 kHz) y los botones ◀ ▶ muestran
    cuánto mueven.
  - «Ir a» acepta kHz (7074) o MHz (7.074 o 7,074).
  - El zoom dice cuánto se ve («234 kHz») en lugar de «Zoom 7».
- **Celular.** Las bandas ocupan una sola fila que se desliza, con la banda activa a la vista.

**Catálogo** (de 52 a 47 herramientas visibles, sin perder ninguna dirección).
- **Retirada.** «Dashboard en Vivo» quedó dentro del centro de mando y su URL lleva a él. Las
  herramientas con `'redirige'` no necesitan grupo; el verificador (3b) lo acepta.
- **Unidas.**
  - «Plan de bandas Colombia» reúne Bandas Colombia, Bandas WARC y el plan visual.
  - «Código Q, RST y fonético» reúne esas tres.
- **Escuchar va primero** y tiene receptor, aperturas, radiofaros (movido desde Explorar) y
  BrandMeister.
- **Movida.** Rastreador DXCC/WAS pasa a Operar.
- **Accesos rápidos.** Ahora son Receptor, Aperturas, QSL y Cobertura.

**Lo que faltaba.**
- **Avísame si aparece.** Una lista de indicativos, prefijos o bandas. Revisa el cluster, POTA y lo
  que oye el receptor, y avisa una vez con un tono y una notificación. Una banda («10m») avisa
  cuando el receptor empieza a oír estaciones en ella.
- **Radiofaros con receptor.** Tienen botones para escucharlos en 14.100, 18.110, 21.150, 24.930
  y 28.200.
- **Frecuencias rápidas.** En HF sintonizan el receptor; las de VHF se siguen copiando.

**Armonía de la consola.**
- Todos los bloques llevan el título fuera de la tarjeta, con el mismo estilo; antes Mi estación,
  Bitácora, Frecuencias, Notas y Satélites lo tenían adentro.
- Nada queda por debajo de 10 px y todas las tarjetas tienen el mismo relleno.

---

## 19.47.1 — concurso en curso y redacción

Ajustes tras revisar la 19.47.0 publicada.

- **Concurso en curso.** Durante el CQ WW DX SSB (24 y 25 de octubre) la franja decía «Próximo: CQ WW
  DX (SSB) — hoy», con el concurso ya corriendo. Ahora dice «🏆 En curso: CQ WW DX (SSB) · termina en
  41 h» y enlaza al calendario. La lista de concursos marca «en curso» en lugar de «0d».
- **«En el Quindío».** `rau_sdr_lugar( true )` pone artículo a los departamentos que lo llevan (el
  Quindío, el Valle del Cauca, La Guajira…) y no a los que no (Antioquia, Caldas…). Los rótulos cortos
  siguen sin artículo («Receptor SDR · Quindío»).
- **Subtítulo.** «Más 62 herramientas en el catálogo» pasa a «Y 62 herramientas más en el catálogo».
- **Conteo por banda.** Una línea aclara que suma las tres fuentes (cluster, POTA y receptor). Antes
  parecía contradecir a la tarjeta «Abierta ahora», que cuenta solo lo oído por el receptor.

---

## 19.47.0 — el receptor como sensor de propagación

Los decodificadores automáticos del KiwiSDR (FT8 y WSPR) suben cada estación que oyen a PSK
Reporter y a WSPRnet con el indicativo HK4RAU. El sitio no lo aprovechaba. Es propagación medida
desde Colombia: el 24-oct-2026, en una hora, 119 estaciones de 30 países en 40 y 20 m.

**Servidor.**
- `rau_sdr_oido`: lee PSK Reporter y wspr.live con una consulta compartida cada 5 minutos, que es lo
  que pide PSK Reporter. Si las fuentes fallan, devuelve el último dato bueno.
- Resume por banda y región: cuántas estaciones, la más lejana y la mejor señal.
- `rau_sdr_aperturas`: con 30 días de WSPR, calcula para cada banda, hora (de Colombia) y región en
  qué porcentaje de los días se oyó algo. Se cachea 6 horas.

**«Abierta ahora · medido».** Es la primera tarjeta de «Mirar». Muestra cada banda que vigila el
receptor con su conteo, sus regiones y la estación más lejana, más una línea «A esta hora suele
abrir…». El semáforo de bandas, «Mejor banda ahora» y la explicación de cada banda usan lo medido.
El índice solar queda solo para las bandas sin medición (80, 30, 17 y 12 m).

**Mapa.** La capa «Lo que oye HK4RAU» traza círculos máximos desde el receptor hasta cada estación
oída en la banda sintonizada. La intensidad depende de la señal. Tocar una estación la sintoniza.

**Lista y cascada.** Hay una tercera fuente, «Oído en HK4RAU», en azul.

**Herramienta nueva: «Aperturas desde Colombia».** Un mapa de calor de banda por hora, con filtro por
región. Hoy tiene 5 días de datos y crece solo.

**Ubicación.** Según su GPS, el receptor está en el Quindío (FJ24ep), no en Medellín. El sitio toma
el nombre del lugar de las coordenadas del GPS (OpenStreetMap, consultado desde el cron solo si el
receptor se mueve). Se cambió en `/receptor/`, la consola, el panel, la portada y el chat.

«Ahora mismo, ¿qué trabajo?» suma las estaciones que el receptor oyó en la banda recomendada.

Se probó contra datos reales: en 30 minutos se oyeron 52 estaciones en 40 m y 17 en 20 m. La más
lejana fue VK3QN, a 14.511 km.

---

## 19.46.2 — mapa gris en celular

En celular, el mapa de la pestaña «Mirar» salía gris. Leaflet lo creaba mientras la pestaña estaba
oculta, lo medía en 0 px y no pedía las imágenes. Ahora un ResizeObserver lo vuelve a medir
(`invalidateSize`) cuando la pestaña se muestra.

---

## 19.46.1 — orden del centro de mando

Ajustes tras revisar la versión publicada.

- **Radio Now, fuera.** Repetía lo que ya está en la consola: la mejor banda (franja superior), el
  estado de HK4RAU (Estado de la red), la ISS (Satélites) y los spots (conteo por banda). En celular,
  además, dejaba el receptor fuera de la primera pantalla. «Mejor banda ahora» se puede tocar y
  sintoniza el receptor en esa banda.
- **Columnas equilibradas.** El mapa estaba en la columna central, que medía 2.170 px frente a
  980 px de la derecha, y dejaba un hueco de 1.200 px. Ahora el mapa ocupa todo el ancho debajo de
  las tres columnas, más alto (30rem); en celular está en la pestaña «Mirar».
- **Redes digitales.** DMR, WSPR y D-STAR pasan al final de la derecha, y las tres columnas quedan
  casi a la misma altura.
- **Estado de la red** pasa a «Comunidad RAU», junto a concursos y racha.
- **Encabezado y bienvenida más cortos.** El subtítulo describe el centro de mando, no solo
  «calculadoras».
- **Vista de una herramienta.** Se ocultan los accesos rápidos y las favoritas, que quedaban entre la
  consola y la herramienta. El buscador sigue a la vista.
- **Plan de bandas.** El rótulo de novicio se corre a la derecha cuando una marca FT8 o WWV cae
  encima.

---

## 19.46.0 — Herramientas como centro de mando

La consola de `/herramientas/` se reorganizó alrededor del receptor del club, en tres columnas:

- **Mirar** (izquierda): estado en vivo, clima espacial, satélites, DMR, WSPR y D-STAR.
- **Escuchar** (centro): el receptor KiwiSDR, las estaciones en la banda y el mapa.
- **Operar** (derecha): Mi estación, bitácora, frecuencias rápidas, notas, progreso y comunidad.

**Todo sigue la frecuencia.** El receptor emite el evento `rau:frecuencia` en cada cambio:
- la bitácora toma la frecuencia y el modo, salvo que la persona los haya escrito a mano;
- el banco «Construir antena» calcula para esa frecuencia;
- la banda actual se marca en el mapa;
- la lista de estaciones se filtra a esa banda.

Tocar una banda del mapa o del conteo sintoniza el receptor.

**Estaciones en la banda.** Reemplaza «DX Spots en vivo». Junta el cluster DX y POTA. Cada estación
muestra país o parque, distancia y rumbo desde Mi QTH, y antigüedad, con tres botones:
🎧 la sintoniza, 📝 la pasa a la bitácora y 📏 la ubica en el mapa. Un conteo por banda muestra
dónde hay movimiento.

**Estaciones sobre la cascada.** Una franja nueva dibuja las marcas ▼ en su frecuencia: ámbar las del
cluster, verdes las de POTA. Tocar una la sintoniza. Sin conexión, la pantalla igual muestra la banda
con su plan, su escala y las estaciones. Si el receptor está lleno, el botón «Avísame cuando haya
canal» revisa cada 30 s y avisa con un tono, una notificación y el título de la pestaña.

**Una herramienta por dirección.** `/herramientas/ahora/` muestra solo «Ahora mismo». La consola se
pliega y quedan accesos a las demás de la categoría y el botón «◉ Centro de mando». En celular,
`/herramientas/ahora/` medía 14.500 px. Ahora `/herramientas/qsl/` mide 1.745 px en computador.
El receptor es uno solo: pasa del centro de la consola al panel «Receptor KiwiSDR» y vuelve sin
cortar el audio.

**Mi estación.** Se guardan indicativo, locator, potencia y antena en el navegador. El locator queda
como Mi QTH. El indicativo llena la QSL, el certificado, PSK Reporter y RBN.

**Celular.** Las tres columnas pasan a pestañas fijas abajo: Escuchar, Mirar, Operar y Explorar. En la
consola, los ajustes avanzados del receptor van plegados.

**Menos carga.** D-STAR, WSPR, BrandMeister (WebSocket), el Sol y la aurora arrancan solo cuando su
panel se ve (`rauCuandoVisible`). Antes corrían en cada una de las 61 URLs.

**Otros cambios.**
- El encabezado fijo tapaba el comienzo de lo que se desplazaba a la vista; ahora hay `scroll-margin-top`.
- Los rótulos FT8 y WWV del plan de bandas se montaban sobre los de novicio; ahora llevan fondo.

Se probó con un receptor simulado y spots de prueba, en computador y en celular. También con el
HK4RAU y los spots reales: 20 m dio S5 y la cascada mostró las estaciones del cluster sobre sus
señales.

---

## 19.45.0 — receptor rediseñado y dentro de Herramientas

El receptor pasó a `inc/receptor-kiwi.php`. Lo usan `/receptor/` y la nueva herramienta
`/herramientas/receptor/` (categoría Escuchar).

**Diseño.** La cascada trae seis paletas. La predeterminada es Ámbar, con las trazas amarillas.
Las otras son Cian RAU, Clásica KiwiSDR, Turbo, Fósforo verde y Grises. El contraste se ajusta con
un deslizador. El piso de ruido sale de la mediana de cada línea, así que la cascada se ve igual en
40 m de noche que en 10 m de día.

La pantalla también tiene:
- un espectro con el promedio de las últimas líneas;
- una escala de frecuencias que se adapta al zoom;
- el ancho del filtro marcado;
- una franja con el plan de bandas colombiano: segmentos de novicio (CW o CW y fonía, Decreto 1078
  art. 2.2.5.6.5), bandas de Primera y Avanzada, y marcas FT8 y WWV.

Antes, las primeras líneas tras conectar o cambiar de banda salían saturadas, porque el piso
arrancaba en −110 dBm. Ahora lo fija la primera línea.

**Sintonía.** Se sintoniza tocando la cascada, arrastrándola para recorrer la banda, con la rueda o
con las flechas del teclado. El paso se elige entre 10 Hz, 100 Hz, 1 kHz y 5 kHz. «Compartir» genera
un enlace `/receptor/?f=7074&m=usb` que abre el receptor en esa frecuencia y ese modo.

**Audio.**
- Filtro Angosto, Normal o Ancho.
- Silenciador con su marca en el S-metro.
- AGC que se puede apagar y botón de silenciar.
- Grabación a WAV de hasta 10 minutos.
- Favoritos guardados en el navegador.

**Herramientas.** Los spots DX, los spots POTA y «Ahora mismo» tienen botón «🎧 Escuchar». El botón
abre el receptor en esa frecuencia, con el modo que le corresponde. El mosaico del tablero mostraba
un espectro falso dibujado a mano. Ahora muestra los canales libres reales y abre la herramienta.
Al cambiar de herramienta mientras suena, aparece una mini barra flotante con la frecuencia y la
señal, y botones para volver o detener. Sin ella, el audio seguía sin forma visible de pararlo.

Se probó con un KiwiSDR simulado (escritorio, móvil y Herramientas) y con el HK4RAU real: 40 m dio
S7 y WWV dio S6, con cascada en ámbar y en Turbo.

---

## 19.44.1 — "7 de 7" no es "lleno"

Con el receptor integrado en vivo, el estado decía "Todos los canales ocupados" y la conexión se
lograba igual. En el código del KiwiSDR (support/stats.cpp, rx/rx_server_ajax.cpp) `users` cuenta los
canales ocupados de los 8, se topa en `users_max` (7, los que no piden clave) y se recalcula cada
pocos segundos. "7 de 7" puede convivir con un canal libre. El sitio dice ahora "Muy ocupado: prueba
igual" y el botón sigue disponible; el aviso de canales llenos solo aparece si el receptor rechaza la
conexión. La gráfica por hora explica cuando todo el período está en el máximo.

---

## 19.44.0 — receptor probado con el KiwiSDR real

Con el relevo publicado (rau-kiwi.danielmontoyae.workers.dev) se probó contra el HK4RAU real:
KiwiSDR 2, v1.902, `mode=rx8.wf3`. WWV en 10 MHz llegó con S9 y la cascada de 40 m mostró las
estaciones en la escala correcta.

**La cascada no mandaba datos.** El receptor empareja audio y cascada por la marca de tiempo de la
URL (`/ws/kiwi/<marca>/SND` y `/W/F`); el cliente usaba una distinta para cada uno, y la cascada se
conectaba pero quedaba vacía. Ahora comparten marca y la cascada se abre 300 ms después del audio,
como hace la interfaz oficial.

**Solo 3 canales con cascada.** El HK4RAU tiene 8 canales de audio y 3 de cascada. Si los de cascada
están ocupados, el receptor sigue sonando y avisa, en lugar de cortar toda la conexión.

---

## 19.43.0 — el KiwiSDR dentro del sitio

**Por qué no se podía.** El KiwiSDR solo habla HTTP: el proxy de kiwisdr.com cierra la conexión
si se le habla TLS (probado en los puertos 443 y 8073) y el propio KiwiSDR no trae HTTPS (su
CHANGE_LOG menciona "Kiwis behind https/ssl proxies"). Desde hk4rau.com, que es HTTPS, el navegador
bloquea su iframe y su WebSocket por contenido mixto; por eso el botón abría otra pestaña.

**Relevo HTTPS gratuito** (`cloudflare-worker/` en el repositorio, fuera del tema): un Cloudflare
Worker en *.workers.dev que pasa páginas y WebSocket al receptor, sigue las redirecciones del proxy
de kiwisdr.com en HTTP y solo acepta WebSocket desde hk4rau.com o desde sí mismo. No requiere mover
el DNS ni equipo en el sitio del receptor. Probado con `wrangler dev`: status, redirección, audio,
cascada y 403 para otros orígenes. Su dirección se guarda en la opción `rau_kiwi_relay`.

**Página /receptor/** (plantilla "Receptor KiwiSDR"): receptor con el diseño del sitio, sobre el
protocolo del KiwiSDR tomado de su código fuente (openwebrx.js, audio.js, kiwiclient): audio
IMA-ADPCM decodificado y remuestreado a la tasa del navegador (Safari antiguo no acepta buffers de
12 kHz), cascada en la paleta del sitio con piso de ruido automático, sintonía por bandas, pasos o
toque en la cascada, modos AM/LSB/USB/CW/FM, zoom, volumen y S-metro. Avisa si los canales están
llenos, si el receptor cierra por inactividad o está en mantenimiento, y libera el canal al cerrar
la página. Sin relevo configurado muestra el estado y enlaza la interfaz original. Probado de punta
a punta (navegador → Worker local → KiwiSDR simulado) en escritorio y celular.

**Estado real y ocupación.** /status ahora da canales libres contando los que ceden los
decodificadores automáticos (`preempt`), antena, versión y tiempo encendido. Una muestra cada 10
minutos (WP-Cron, 14 días) alimenta "Canales libres por hora". El 23-oct-2026 el receptor estaba 7
de 7 ocupado: sin decodificadores que cedan el canal, nadie puede escuchar.

**Portada.** La tarjeta del KiwiSDR dibujaba un espectro a mano ("estético", decía el código) y
decía "En línea" aunque estuviera lleno. Ahora muestra la ocupación por hora real, "Canal libre",
"Lleno" o "Fuera de línea", y lleva a /receptor/. El estado del Dashboard y de Estado RAU leía un
campo inexistente (`users_audio`) y nunca mostraba usuarios; ahora muestra canales libres. Los
enlaces http:// al KiwiSDR del chat, Canales y Herramientas van a /receptor/.

---

## 19.42.0 — portada con fecha, repetidoras para programar, sin Programa Elmer

**El Programa Elmer no existe.** El chat lo ofrecía, la guía de la licencia lo enlazaba y había una
página con su plantilla. La página quedó en borrador, se quitaron `page-elmer.php`, su descripción
SEO y su sección en INSTRUCCIONES.md, y la respuesta del chat ahora es "Estoy empezando, ¿me
ayudan?": guía de la licencia, simulador, programa de los martes y WhatsApp. Sigue respondiendo a
quien escriba "elmer" o "mentor".

**La portada no decía que el sitio está vivo.** Bajo el hero, tres tarjetas que cambian solas: la
próxima actividad con su fecha, la guía de la licencia y el último mensaje del Libro de Visitas con
"hace N días". Radio RAU, que es un juguete, pasó del segundo lugar al final. "Historias de la
Comunidad" se oculta con menos de dos historias (había una y la sección parecía abandonada); el
Libro de Visitas, justo debajo, ya cumple esa función. "Faltan 1 días" ahora es "Empieza mañana".
"Cómo asociarse" enlaza primero la guía de la licencia.

**Repetidoras.** La portada mostraba las 4 últimas publicadas y dejaba fuera a Medellín, la
principal. Ahora salen todas, la principal (HK4RAU) primero y las demás por nombre, igual que en el
directorio (`rau_ordenar_repetidoras()`; antes ordenaba por fecha). Las tarjetas muestran el tono.
Un indicativo que no es indicativo ("PENDIENTE") se muestra como "Indicativo por confirmar".

**Ficha de repetidora: "Programa tu radio".** La ficha daba frecuencia y tono pero no el
desplazamiento, y nadie decía la frecuencia de transmisión. Nueva fila "Desplazamiento" y una
tarjeta con RX, TX calculada, desplazamiento y tono, más los pasos para configurar el radio.
`rau_programacion_repetidor()` entiende "-600 kHz", "-0.600" y "+5 MHz"; si falta un dato no
muestra una TX inventada. Probado con seis formatos.

**Probado en un WordPress local** (7.1.3 con SQLite y datos de prueba): portada, directorio y
ficha en escritorio y celular, sin errores de PHP.

---

## 19.41.0 — el chat explica la licencia paso a paso

Sacar la licencia es la duda más común de quien llega, y el chat solo respondía "practica con el
simulador". La "Guía para la Licencia" del sitio era una línea con un enlace.

**Nueva página /como-sacar-la-licencia/** (contenido de WordPress, no del tema): el trámite completo
ante el MinTIC en seis pasos, con dónde y cómo hacer cada uno, los valores de 2026, los datos de
pago, el indicativo por zona, renovación, ascenso a Primera y preguntas frecuentes. Verificada el
23 de octubre de 2026 contra las páginas RABCA del MinTIC (Novicio, actualizada el 27-jun-2025;
Primera, 2-feb-2026), la Circular 009 de 2026 de costos, el temario oficial y el Decreto 1078 de
2015 (arts. 2.2.5.2.3, 2.2.5.2.4, 2.2.5.6.5 y 2.2.5.7.1).

**El chat recorre el trámite.** Nueve respuestas sobre la licencia (cómo sacarla, examen, costo,
pago, documentos, demora, indicativo, renovación y ascenso) en lugar de una. Después de cada
respuesta ofrece las preguntas que suelen venir a continuación, y los botones iniciales empiezan
por la licencia. Las específicas van antes que la general en la lista, porque a igual puntaje gana
la primera: "¿cuánto cuesta la licencia?" responde el costo. Probado con 11 preguntas escritas como
las haría alguien; "se me venció la licencia" caía en el resumen general y se corrigió.

**Respuestas que no eran ciertas.** "Asociarse" pedía registrarse en el sitio, que no tiene
registro; "herramientas" decía "más de 35" (son 60, ahora contadas del registro); "Elmer" mandaba
a un menú y ahora enlaza la página.

**Viñetas en las páginas.** El preflight de Tailwind quitaba viñetas y números de las listas del
editor: los pasos de una guía se leían como párrafos sueltos.

**Enlaces a la guía** en el pie del sitio y en el simulador de examen, que avisa además de que el
examen real incluye cultura general.

---

## 19.40.0 — los errores avisan; el celular estorba menos

**Aviso por correo de errores de JavaScript.** "Ahora mismo" estuvo rota desde su publicación sin
que nadie lo supiera, porque su `.catch()` mostraba un aviso de red. Un script en `wp_head`
escucha los errores sin atrapar y las promesas rechazadas, y `rauErr(e)` se agregó a los 48
`.catch()` del tema (todos menos el registro del service worker). Solo se avisan errores de
programación (ReferenceError, TypeError, SyntaxError, RangeError) que no sean cortes de red, y solo
de scripts del propio sitio. Llegan a `admin_email` con el mensaje, la línea, la página, la versión
del tema y el navegador. Límites: cada error distinto una vez al día, 3 avisos por visitante cada
10 minutos, 10 correos al día en total. Probado contra el sitio en vivo con el fallo de "Ahora
mismo" todavía publicado: un solo aviso, el correcto, y ninguno por errores de red.

**El botón del chat tapaba texto en el celular.** Baja de 56 a 48 px en pantallas pequeñas y se
aparta al desplazarse hacia abajo; vuelve al subir. Con el chat abierto no se mueve.

**Zonas táctiles de 12–17 px.** Spots DX, frecuencias para copiar, satélites y canales solares
eran botones de texto demasiado bajos para un dedo. En pantallas táctiles miden ahora 24 px, el
mínimo de WCAG 2.2; los enlaces del pie y las casillas del mapa también crecen.

**/herramientas/dxcc/ abría bajo el borde de la pantalla.** Las herramientas de arriba terminaban
de cargar después del salto y empujaban el panel. Se vuelve a alinear al terminar la carga, salvo
que la persona ya haya empezado a moverse.

---

## 19.39.0 — revisión de las 60 herramientas en producción

Se abrieron las 60 URLs /herramientas/{id}/ en un móvil simulado, registrando también los errores
que el código atrapa sin mostrar.

**"Ahora mismo, ¿qué trabajo?" nunca funcionó en producción.** Mostraba "No se pudieron leer las
condiciones" aunque los datos solares y los spots llegaban bien. Leía `RAU_QTH_MAPA`, una variable
declarada dentro del bloque del mapa y por tanto invisible desde el suyo: `ReferenceError`, que el
`.catch()` convertía en un aviso de red. Como la página carga todas las herramientas, el error se
repetía en las 60 URLs. El botón "Mi QTH" del conversor de coordenadas tenía el mismo fallo. Ahora
las dos usan `rauQth()`, una sola función global para el QTH guardado o Medellín.

**Comprobación 19, nueva.** Busca constantes en mayúsculas declaradas dentro de un bloque y leídas
desde otro. Probada reintroduciendo el fallo: lo detecta y da los bloques; sin él, pasa.

**El nombre de la herramienta quedaba bajo la cabecera.** Al abrir /herramientas/{id}/ la página
bajaba hasta la herramienta y la cabecera fija (4rem) tapaba su título. `scroll-padding-top` en
`html` lo corrige para todo salto del sitio.

**Un solo H1 para 60 URLs.** Cada herramienta tenía su propio `<title>` y descripción, pero todas
compartían "Herramientas de Radio" como encabezado principal. Ahora el H1 es el nombre de la
herramienta.

**Calendario .ics: `\n` literal en la descripción.** `implode('\n')` con comillas simples dejaba
una barra que `rau_ics_escape()` volvía a escapar: Google Calendar mostraba "rueda\nFrecuencia".

---

## 19.38.0 — lo que ve quien llega por primera vez

**El splash tapaba la portada 5,5 segundos.** En la primera visita de cada sesión el escudo cubría
la página entera y no se podía hacer nada hasta que terminara la animación. Medido con un móvil
simulado: 5.563 ms. Ahora dura 1,6 s con la misma animación, y se salta con un toque o con Esc.

**Instrucciones del escritorio a la vista del público.** Cuando una sección estaba vacía, cualquier
visitante leía "Agrégalos en el escritorio → …". Tras retirar los datos de ejemplo eso pasaba en el
Libro QSL, Turnos y Próximas actividades. Ahora esa indicación solo la ve quien puede editar; el
público lee un mensaje neutro. Portada (repetidores, eventos, historias), Directorio, Pulguero,
Libro QSL, Documentos, Junta Directiva y Turnos.

**"1 repetidores".** El contador de la portada concuerda en número.

**Eventos semanales que caducaban.** La portada y el calendario solo muestran eventos de hoy en
adelante, y un evento tiene una sola fecha: la malla de los martes desaparecía a los siete días.
Campo nuevo `recurrencia` (`semanal`): cuando la fecha pasa, se corre sola al mismo día de la
semana siguiente. En el calendario .ics sale con `RRULE:FREQ=WEEKLY`.

**Campos del evento en la API.** `start`, `type`, `frequency`, `location` y `recurrencia` quedan
declarados con `register_post_meta`. Antes la API REST los ignoraba sin avisar, así que un evento
creado por esa vía no tenía fecha y no aparecía en ningún lado.

**Iconos sociales sin nombre.** WhatsApp, Instagram, Facebook y YouTube del pie eran enlaces con
solo un SVG: un lector de pantalla los anunciaba como "enlace". Llevan `aria-label` y el SVG se
oculta a la accesibilidad.

---

## 19.37.0 — análisis del sitio en producción

Se recorrieron desde fuera las 134 URLs del sitemap de hk4rau.com con un navegador real
(escritorio y móvil), 230 enlaces, axe-core en 12 páginas y el peso de cada página. Los cambios se
probaron después en un WordPress 7.1.3 local con el tema, contenido de prueba y el mismo navegador.

**Ninguna URL de herramienta mostraba su herramienta.** `/herramientas/qsl/` abría la página y
enseñaba el tablero "Radio Now": el panel de la QSL se activaba, pero dentro del catálogo, que vive
en el modo "Catálogo" de la consola y estaba oculto. Medido en producción: 0 de 60. Con la
corrección: 60 de 60, en pantalla y sin errores. `activateCategory()` pasa ahora a ese modo con el
mismo clic que usa el botón "+ Más herramientas", y quien llega por la URL de una herramienta ve su
panel. Ninguna comprobación lo detectaba: todas miraban el código, ninguna lo que se ve. La 18 lo
vigila.

**Seguridad.**
- `bin/verificar.php` se ejecutaba desde la web: pedir su URL lo ponía a correr en el servidor, sin
  límite. Ahora solo funciona desde la línea de comandos y responde 404 al resto.
- El usuario administrador se publicaba en `/wp-json/wp/v2/users`, en `/?author=1` (la cabecera
  `Location` de la redirección ya lo revelaba) y en el sitemap de usuarios. Las tres vías cerradas
  para visitantes anónimos; el escritorio y las contraseñas de aplicación siguen viéndolo.
- Cabeceras que el alojamiento no enviaba: HSTS (un año, sin subdominios), `nosniff`,
  `X-Frame-Options: SAMEORIGIN` y `Referrer-Policy`. Sin `Permissions-Policy`: varias herramientas
  piden la ubicación. `X-Powered-By` ya no anuncia la versión de PHP.

**Privacidad del directorio.** La página decía "solo aparecen los miembros que autorizaron
publicar sus datos" y listaba a todos: el campo `visible` solo existía en un comentario. Ahora hay
una casilla "Directorio público" en la ficha de cada miembro y sin ella no aparece. Además, la API
REST publicaba el nombre de todos los miembros y cada uno tenía su página `/miembro/{nombre}/`
indexada. **Después de desplegar, el directorio queda vacío hasta marcar la casilla de quienes
autorizaron.**

**Fichas vacías.** Miembros, turnos, QSO y directivos tenían página propia que solo mostraba el
título (`single.php` no tiene vista para esos tipos): unas 15 páginas indexadas sin contenido. Ya no
son consultables por URL; siguen en el escritorio y en las páginas que los listan.

**SEO.**
- Canonical: categorías, etiquetas, autores y las páginas 2, 3… de cualquier listado declaraban la
  portada como su URL canónica. Ahora cada una la suya; búsquedas y 404 no llevan.
- 41 páginas salían con `<meta name="description" content="">`. Ahora la descripción sale de los
  datos de la página: los campos del repetidor o del evento, o la introducción de su plantilla.
- RAU Field no tenía `<h1>`.

**Rendimiento.** Las páginas de herramientas pesaban 2–4,2 MB contra 700 KB de la portada:
- El widget de DXheat (hasta 1,8 MB, con su propio contador Piwik) se cargaba en las 60 URLs aunque
  nadie abriera el panel: `loading="lazy"` no aplaza un iframe oculto. Ahora usa `data-src` y se
  carga al abrir su panel. De ahí salían los avisos de cookies `_pk_` en la consola.
- El generador de QSL descargaba sus tres fotos de fondo (~1 MB) en cada herramienta, y el fondo
  por defecto no usa ninguna. Ahora cada foto se pide al elegir su fondo.
- Fuera el script de emojis de WordPress (hasta 73 KB por página).

**Accesibilidad y móvil.**
- Textos con opacidad 50 % daban contraste 2,8:1 (calculado y coincidente con axe: 2,81). Pasan a
  opacidad completa: 7,1:1 en oscuro, 5,6:1 en claro. Los iconos de 30–40 % son decorativos.
- Los enlaces `text-primary hover:underline` dentro de un párrafo solo se distinguían por el color
  (1,32:1 con el texto). Ahora van subrayados.
- El marcador de la ISS en el mapa no tenía nombre para lectores de pantalla.
- Los archivos de categoría y autor mostraban el título con las etiquetas escapadas
  ("Categoría: &lt;span&gt;…") y esa cadena, sin espacios, desbordaba en móvil. Una URL larga en
  la guía de licencia también.

**Comprobación 18, nueva**: que `activateCategory()` pase al modo Catálogo y que ningún iframe de
terceros en Herramientas lleve `src`. Probada reintroduciendo cada fallo por separado.

**Queda fuera del tema** (panel de WordPress / Hostinger): despublicar el contenido de ejemplo
(alerta "Malla de Emergencia activada", QSO HK3ZZZ y HK4WWW, miembros y turnos de prueba,
"historia-1" a "historia-3", "Hello world!"), cambiar el nombre público del administrador, que hoy
es su correo, y borrar `readme.html` y `license.txt`. Tras desplegar, purgar la caché de LiteSpeed:
guarda también las cabeceras.

---

## 19.36.0 — campos vacíos y JavaScript validado

**No existe una 19.35.0 publicada.** En una sesión de trabajo apareció una copia marcada 19.35.0
con una herramienta `cobreal` (Cobertura Real) cuyo origen nadie pudo explicar, y no se integró.
Se salta el número para que no se confunda con aquella copia. Esta versión parte de la 19.34.0
desplegada, que desde ahora vive en git.

**Campos vacíos que daban un resultado.** La comprobación 11 contaba 13 usos de `parseFloat(x)||0`
y en realidad había 31: su expresión regular no veía el paréntesis anidado de
`getElementById('x').value`. Revisados uno a uno, cinco herramientas convertían un campo borrado
en un número falso:

- **Autonomía de batería** (y la versión corta del Centro de mando): un consumo en RX o TX borrado
  contaba como 0 mA y la autonomía salía inflada. Es la cifra con la que se planea una emergencia.
- **Carta de Smith** y su versión del banco rápido: R vacía daba ROE ∞:1, como una antena en corto.
- **Field Day**: capacidad vacía daba "0h 0m".
- **Split**: frecuencia vacía daba "0.0 kHz".
- **Perfil de terreno**: una altura de antena vacía se calculaba como 0 m sin avisar. Ahora lo pide
  antes de consultar las elevaciones.

Ahora muestran "—" o piden el dato. En los 16 usos restantes el cero sí es un valor real (contadores
DXCC/WAS vacíos, índices de `<select>`, datos que nunca se guardaron, X = 0 en una carga resistiva,
split sin desplazamiento) y cada uno lo declara en la misma línea con `/* 0 legítimo: motivo */`.

**Comprobación 11, de aviso a fallo.** Ya no se conforma con contar: un `||0` sin esa marca hace
fallar el guion. Recorre todos los archivos, no solo el de Herramientas. Probada reintroduciendo
el fallo de la batería (con paréntesis anidado) y el de Field Day: detecta los dos, y no salta con
`||0.95` ni con los comentarios que citan el patrón.

**Comprobación 17, nueva: sintaxis JavaScript.** `php -l` no mira el JavaScript que vive dentro de
los `.php`. La comprobación sustituye cada bloque PHP por un `0`, conservando los saltos de línea, y
pasa cada `<script>` por `node --check` por separado, como lo trata el navegador: 21 bloques. Probada
con tres errores en tres archivos distintos; los detecta los tres y da la línea exacta. Sin `node`
instalado, avisa en vez de fallar.

---

## Pendiente

**Consulta jurídica.** El normograma del MinTIC marca los artículos 29 (atribución de bandas) y 34
(bandas del Novicio) del Decreto 963 de 2009 como **no compilados** en el Decreto Único 1078 de
2015, con remisión a su artículo 3.1.1. Los artículos 35 y 38 —distintivos y potencias— sí quedaron
compilados. O sea que la parte que dice a un Novicio en qué bandas puede operar quedó fuera de la
compilación oficial, mientras que la que dice con cuánta potencia sí. La tabla lleva una nota que
explica la situación sin pronunciarse. Merece que alguien con criterio jurídico lo mire, o una
consulta directa al MinTIC: una tabla que un socio consulta antes de transmitir no debería quedarse
en "probablemente sigue vigente".
